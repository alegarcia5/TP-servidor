#!/bin/bash

# funcion de ayuda
show_help(){
echo "Uso: $0 [origen] [destino]"
echo "Ejemplo: $0 /var/log /backup_dir"
echo "Opcion: -help -> Muestra esta ayuda"
}

# validar argumentos
if [ "$1" == "-help" ]; then
	show_help
	exit 0
fi

if [ $# -ne 2 ]; then
	echo "Error: Se requieren origen y destino"
	show_help
	exit 1
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")

# validar sistemas de archivos
if [ ! -d "$ORIGEN" ] || [ ! -d "$ORIGEN" ]; then
	echo "Error: Directorios no validos o no disponibles"
	exit 1
fi

# crear backup comprimido
tar -czf "${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz" -C "$ORIGEN" .

echo "Backup completado: ${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"

